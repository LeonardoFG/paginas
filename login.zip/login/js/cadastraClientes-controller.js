import { clienteService } from '../js/cliente-service.js'

const formulario = document.querySelector('[data-form]')


formulario.addEventListener('submit', async (evento) => {
  evento.preventDefault()
  
  try {
    const email = evento.target.querySelector('[data-email]').value
    const psw = evento.target.querySelector('[data-psw]').value
    const pswr = evento.target.querySelector('[data-pswr]').value

    if(psw === pswr){
      await clienteService.criaCliente(email, psw)
      window.location.href = '../cadastro_concluido.html'
    } else {
      throw new Error('as senhas não conferem')
    }
  }
  catch (erro) {
    console.log(erro)
    window.location.href = "../erro.html"
  }
})